ASU Portable v3, 2026-09-12
Start with CONVERSION_PROMPTS_MASTER.md. The main prompt is standalone; the other files are optional support.
Read question-workflow/START_TO_FINISH.md for the user steps. Use the dated destination snapshot only at the website mapping stage and refresh it before import.
The five original Pulse prompts are preserved in the source project but are not required by this package.
