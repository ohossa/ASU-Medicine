# Medical Image Extraction: Technical Reference

## 1. Caption Extraction Regex Patterns by Textbook

| Textbook | Target Format | Production Regex | Notes |
|---|---|---|---|
| **Netter Collection** | `Plate 1-7 BLADDER...` | `r"(?:PLATE\|Plate)\s+([0-9A-Za-z]+[\–\-][0-9A-Za-z]+)\s+([^\n]+)"` | Handles section and plate identifiers. |
| **Robbins Pathology** | `Fig. 14.7 Glomerular...` | `r"Fig(?:\.\|ure)\s*(\d+[\.\-]\d+)\s+([^\n]+)"` | Accommodates dot or hyphen delimiters. |
| **Wheater Histology** | `FIG. 18.4 Seminiferous...` | `r"FIG\.\s*(\d+[\.\-]\d+)\s+([^\n]+)"` | Pairs with footer abbreviation bar detection. |
| **Junqueira Histology** | `FIGURE 21–4 Seminiferous...` | `r"FIGURE\s*(\d+[\–\-]\d+)\s+([^\n]+)"` | Handles Unicode en-dash and hyphen. |
| **The Developing Human** | `F I G U R E  1 2 – 1 8...` | `r"F\s*I\s*G\s*U\s*R\s*E\s*1\s*2\s*[\–\-]\s*([0-9\s]+)"` | Matches letter-spaced tracked lettering across all 49 figures. |
| **Lippincott Histology** | `FIGURE 20.17 Drawing...` | `r"FIGURE\s*(\d+[\.\-]\d+)\s+([^\n]+)"` | Distinguishes in-text figures from Atlas Plates. |
| **Netter Systems Atlas** | `Plate S-459 Kidneys...` | `r"(?:PLATE\|Plate)\s+([A-Za-z0-9]+[\–\-](?:BP\s*)?[0-9]+)[\•\.\s\n]+([^\n]*)"` | Captures standard plates, Plate S-467, and Bonus Plates (`S-BP 83–94`). |

---

## 2. Dynamic Bounding Box & Prose Exclusion Formula

```python
# Narrative Prose Exclusion:
# Detects multi-word blocks above the caption that exceed column width thresholds
narrative_y1 = [prev_y]
for b in page.get_text("blocks"):
    txt = b[4].strip()
    r = fitz.Rect(b[:4])
    if r.y1 <= c_box.y0:
        words = txt.split()
        is_caption = bool(re.match(r"^F\s*I\s*G\s*U\s*R\s*E", txt, re.IGNORECASE))
        if not is_caption:
            if len(words) > 12 or (r.width > page.rect.width * 0.45 and len(words) > 4):
                if r.x1 >= c_box.x0 - 50.0 and r.x0 <= c_box.x1 + 50.0:
                    narrative_y1.append(r.y1)
effective_prev_y = max(narrative_y1)

# Dynamic Artwork Union:
# Finds embedded images bounded between effective_prev_y and caption box
matching_imgs = [
    r for r in img_rects
    if r.y0 >= effective_prev_y - 20.0 and (
        (r.y1 <= c_box.y0 + 25.0 and r.y0 >= c_box.y0 - 550.0) or
        (r.y0 <= c_box.y1 and r.y1 >= c_box.y0)
    )
]
if matching_imgs:
    fig_rect = matching_imgs[0]
    for r in matching_imgs[1:]:
        fig_rect |= r
    crop_box = fitz.Rect(
        max(35.0, min(fig_rect.x0, c_box.x0) - 10.0),
        max(effective_prev_y, min(fig_rect.y0, c_box.y0) - 10.0),
        min(page.rect.width - 35.0, max(fig_rect.x1, c_box.x1) + 10.0),
        min(page.rect.height - 35.0, max(fig_rect.y1, c_box.y1) + 10.0),
    )
```

---

## 3. Multi-BBox Vertical Stitching Implementation

```python
from PIL import Image

def extract_stitched_figure(pdf_path: str, page_idx: int, main_bbox: fitz.Rect, footer_bbox: fitz.Rect, output_path: str, dpi: int = 300):
    matrix = fitz.Matrix(dpi / 72.0, dpi / 72.0)
    with fitz.open(pdf_path) as doc:
        page = doc[page_idx]
        pix_main = page.get_pixmap(matrix=matrix, clip=main_bbox, alpha=False)
        pix_foot = page.get_pixmap(matrix=matrix, clip=footer_bbox, alpha=False)

    im_main = Image.frombytes("RGB", [pix_main.width, pix_main.height], pix_main.samples)
    im_foot = Image.frombytes("RGB", [pix_foot.width, pix_foot.height], pix_foot.samples)

    gap = 10
    total_w = max(im_main.width, im_foot.width)
    total_h = im_main.height + gap + im_foot.height

    canvas = Image.new("RGB", (total_w, total_h), (255, 255, 255))
    canvas.paste(im_main, ((total_w - im_main.width) // 2, 0))
    canvas.paste(im_foot, ((total_w - im_foot.width) // 2, im_main.height + gap))
    canvas.save(output_path, "PNG", dpi=(dpi, dpi))
```

---

## 4. Master Index Schema Contract

Every record in `UNIFIED_MASTER_IMAGE_INDEX.csv` and `UNIFIED_MASTER_IMAGE_INDEX.json` conforms to:

| Field Name | Type | Description | Example |
|---|---|---|---|
| `image_id` | `string` | Unique alphanumeric identifier | `NETTER_URI_P026_Plate_1_7_subfig1_paramedian_dissection` |
| `filename` | `string` | Physical basename on disk | `NETTER_URI_P026_Plate_1_7_subfig1_paramedian_dissection.png` |
| `relative_path` | `string` | Portable path relative to workspace | `Urogenital_Textbook_Visual_Library/01_Netter_Urinary_System/SEC01_ANAT/...png` |
| `origin` | `string` | `"medical_textbook"` or `"university_lecture"` | `"medical_textbook"` |
| `book_name` | `string` | Normalized textbook key | `"netter_urinary"` |
| `book_title` | `string` | Full canonical book title | `"The Netter Collection of Medical Illustrations: Urinary System, Vol 5"` |
| `figure_id` | `string` | Authentic plate/figure number | `"Plate 1-7"` |
| `subject` | `string` | Medical curriculum discipline | `"Anatomy"` |
| `lecture` | `string` | Associated curriculum lecture topics | `"Anatomy_of_Kidney; Lab_1_anatomy_urinary_system"` |
| `topic` | `string` | Specific anatomical/histological topic | `"Urinary Bladder Position and Relations"` |
| `caption` | `string` | Authentic textbook caption & legend | `"Plate 1-7 Male Urinary Bladder: Paramedian (Sagittal) Dissection..."` |
| `dimensions` | `string` | Width x Height in pixels | `"1726x1430"` |
| `width` | `integer` | Pixel width at 300 DPI | `1726` |
| `height` | `integer` | Pixel height at 300 DPI | `1430` |
| `html_img_tag` | `string` | Anki-ready HTML image tag | `<img src="NETTER_URI_P026_Plate_1_7_subfig1_paramedian_dissection.png">` |

---

## 5. Verification Commands

```bash
cd /Users/omarhossa/Documents/Codex/2026-09-20/h

# 1. Full QA Runner (27 checks covering all 7 pillars)
python3 tests/run_tests.py

# 2. Adversarial Challenger Runner (12 empirical test oracles)
python3 tests/run_tests.py --challenger

# 3. Pytest E2E Verification Suite (26 assertions)
pytest tests/test_e2e_visual_library.py -v

# 4. Interactive Search Verification
python3 match_for_card.py -q "podocyte filtration slit" -s "Histology" -k 2
```
