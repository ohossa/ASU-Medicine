---
name: medical-image-extraction
description: "Extract, cleanly crop, and catalog medical textbook figures, atlas plates, and micrographs with vector labels and authentic captions. Use when extracting images from medical textbooks, splitting multi-figure pages, stitching distant abbreviation bars, organizing curriculum visual libraries, generating Anki image tags, or resolving medical image quality issues."
user-invocable: false
metadata:
  author: ASU Medicine
  version: "1.0.0"
---

# Medical Image & Visual Asset Extraction

Governing procedure for extracting, cleanly cropping, vector-rendering, cataloging, and testing high-yield medical visual assets from medical textbooks and lecture slides for direct Anki flashcard integration.

## Quick Start

```python
import fitz
from PIL import Image

# 1. Native 300 DPI vector rendering with 100% anatomical labels
matrix = fitz.Matrix(300 / 72.0, 300 / 72.0)
doc = fitz.open("textbook.pdf")
page = doc[page_num]

# 2. Strict bounding box (excluding adjacent column text)
crop_bbox = fitz.Rect(x0, y0, x1, y1)
pix = page.get_pixmap(matrix=matrix, clip=crop_bbox, alpha=False)
pix.save("output_figure.png")
```

Search extracted assets using the CLI tool:
```bash
cd /Users/omarhossa/Documents/Codex/2026-09-20/h
python3 match_for_card.py -q "podocyte filtration slit" -s "Histology" -k 2
```

## Why: The 7 Pillars of Visual Perfection

1. **Multi-Figure Page Splitting**: Never bundle multiple independent figures in one image (e.g. Netter Plate 1-7 paramedian vs. median sections must be two distinct standalone files).
2. **Sub-Panel Unification**: Multi-panel figures with a shared caption (e.g. Wheater Fig 18.5 panels a & b) must remain unified in one file with their authentic legend.
3. **Strict Exclusion of Body Prose**: Left-column paragraphs and chapter headers (`INTRODUCTION`, `ORGAN SYSTEMS`) must never bleed into crops.
4. **Zero Synthetic Cards & Fluff**: Never generate artificial Pillow cards, fake "CLINICAL PEARLS", or tag clouds. Keep crops authentic to the textbook.
5. **Authentic Captions Directly Below Visual**: Always include genuine textbook legends decoding callout letters (`TA`, `E`, `RT`, `S`, `C`, `Se`, `SA`, `St`, `M`).
6. **Native 300 DPI Vector Viewports**: Always rasterize the PDF viewport at 300 DPI (`fitz.Matrix(300/72, 300/72)`); never extract raw embedded bitmaps (`get_images()`) which discard vector labels and leader lines.
7. **Clean Replacement & Zero Stale Remnants**: Maintain 100% 1:1 match between disk files and the master index; 0 unindexed files, 0 broken symlinks.

## Workflow

```text
[Resolve PDF Path]
       │
       ▼
[Find Figure Captions] ──► Handle letter-spaced tracking & linebreaks
       │
       ▼
[Compute Artwork BBox] ──► Dynamic image rects; clip narrative column text
       │
       ▼
[Check Splitting/Stitch] ─► Split multi-figures; stitch distant abbreviation footers
       │
       ▼
[Render at 300 DPI] ────► Rasterize vector viewport; validate min 800x600 px
       │
       ▼
[Symlink & Catalog] ────► Symlink into Curriculum Library; add to master CSV/JSON
       │
       ▼
[Run Verification QA] ──► 27-check QA runner + 12-check challenger suite (100% pass)
```

## Anti-Patterns

| WRONG | RIGHT |
|---|---|
| Extracting raw bitmap streams via `page.get_images()` or `pdfimages`, losing vector text labels. | Rendering the full viewport via `page.get_pixmap(matrix=fitz.Matrix(300/72, 300/72), clip=bbox)`. |
| Bundling 2 figures from 1 page together into a single giant crop. | Splitting each figure into an independent image with its own caption. |
| Using Pillow to create a synthetic card with blue bars and fake "CLINICAL PEARLS". | Keeping the pure visual artwork and authentic textbook legend below it. |
| Leaving a 700 px blank whitespace void between a micrograph and its footer abbreviation key. | Vertical multi-bbox stitching to attach the abbreviation bar directly below the caption. |
| Renaming files with `FIG__` (double underscore) or `Plate_S–...` (Unicode en-dash). | Normalizing underscores (`re.sub(r'_+', '_', ...)`) and ASCII hyphens. |

## Checklist

- [ ] Viewport rendered at native 300 DPI vector resolution.
- [ ] 100% of anatomical labels, arrows, and leader lines intact.
- [ ] Authentic textbook caption stitched directly below visual.
- [ ] Distant abbreviation keys stitched; no whitespace voids.
- [ ] No narrative body text or chapter banner headers in image.
- [ ] No synthetic Pillow cards or fabricated clinical pearls.
- [ ] Clean normalized filename (no `FIG__`, no en-dashes, exact case match).
- [ ] Symlinked into `Urogenital_Unified_Curriculum_Library/` with 0 broken links.
- [ ] Added to `UNIFIED_MASTER_IMAGE_INDEX.csv` and `.json` with Anki `<img>` tag.
- [ ] Verified with `python3 tests/run_tests.py` (27/27 pass) and `--challenger` (12/12 pass).

## See Also
- Complete Workflow Guide: [`IMAGE_EXTRACTION_WORKFLOW.md`](file:///Users/omarhossa/Documents/Medcine%20ASU/ASU-Medical-Portal/IMAGE_EXTRACTION_WORKFLOW.md)
- Algorithms & Technical Reference: [`REFERENCE.md`](file:///Users/omarhossa/Documents/Medcine%20ASU/ASU-Medical-Portal/.agents/skills/medical-image-extraction/REFERENCE.md)
- Worked Before/After Examples: [`EXAMPLES.md`](file:///Users/omarhossa/Documents/Medcine%20ASU/ASU-Medical-Portal/.agents/skills/medical-image-extraction/EXAMPLES.md)
