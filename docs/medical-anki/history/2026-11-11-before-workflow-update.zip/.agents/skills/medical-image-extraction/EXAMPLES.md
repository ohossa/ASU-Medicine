# Medical Image Extraction: Worked Examples & Transformations

## Example 1: Multi-Figure Page Splitting (Netter Plate 1-7)

### Context & Flawed Initial State
Page 26 of *The Netter Collection: Urinary System (Vol 5)* contains two distinct views of the male bladder:
1. Paramedian (sagittal) dissection (top)
2. Median (sagittal) section (bottom)
Adjacent left-column contains narrative body paragraphs (`BLADDER: POSITION, RELATIONS, GROSS STRUCTURE`).  
**Initial Flaw**: Both drawings were captured in a single 3000x2000 px crop with the left text column partially clipped and a synthetic Pillow card (`CLINICAL PEARLS`) pasted below.

### The Pure Extraction Transformation
- Sub-figure 1:
  - BBox: `fitz.Rect(185.0, 48.0, 560.0, 435.0)`
  - Output: `01_Netter_Urinary_System/SEC01_ANAT/NETTER_URI_P026_Plate_1_7_subfig1_paramedian_dissection.png` (1726x1430 px)
  - Features: 0 column prose, 0 synthetic pearls, 100% anatomical callouts (`Vas deferens`, `Ureter`, `Seminal vesicle`, `Prostate`, `Retropubic space`) intact.
- Sub-figure 2:
  - BBox: `fitz.Rect(185.0, 440.0, 560.0, 720.0)`
  - Output: `01_Netter_Urinary_System/SEC01_ANAT/NETTER_URI_P026_Plate_1_7_subfig2_median_sagittal_section.png` (1726x1101 px)
  - Features: Cleanly separated internal anatomy (`Trigone`, `Ureteric orifice`, `Sphincter urethrae`).

---

## Example 2: Distant Abbreviation Key Vertical Stitching (Wheater Fig 18.4)

### Context & Flawed Initial State
Page 339 of *Wheater's Functional Histology (6th Ed.)* displays Fig 18.4 (Seminiferous tubules H&E).  
The callout letters on the micrograph (`C`, `E`, `I`, `RT`, `S`, `Se`, `TA`) are decoded in a distant footer abbreviation bar at `y0=740.0` (`C capillary | E epididymis | I interstitium...`).  
**Initial Flaw**: A standard single bounding box either clipped the footer bar (leaving students unable to decode what `Se` stands for), or included 700 px of empty page margin between the caption and footer.

### The Vertical Stitching Transformation
- Visual + Caption Box: `fitz.Rect(35.0, 345.0, 510.0, 670.0)`
- Abbreviation Footer Box: `fitz.Rect(35.0, 738.0, 510.0, 755.0)`
- Output: `05_Wheaters_Functional_Histology/CH18_MALE/WHEATER_HISTO_P351_Fig_18_4_seminiferous_tubules_abbrev.png` (2030x1401 px)
- Result: Micrograph, authentic caption, and abbreviation bar stitched seamlessly with a 10 px separator, eliminating the 700 px whitespace void.

---

## Example 3: Sub-Panel Cohesion Preservation (Wheater Fig 18.5)

### Context & Requirement
Page 340 of *Wheater's Functional Histology* contains Fig 18.5 with:
- Panel (a): High-power H&E micrograph of seminiferous epithelium with cell labels (`SA`, `SB`, `S1`, `S3`, `S4`, `St`, `M`).
- Panel (b): Diagrammatic flowchart of spermatogenesis stages.
- Caption: Single unified legend describing both panels and decoding `SA` to `Type A spermatogonia`, `St` to `Sertoli cell`, etc.  
**Requirement**: Because panel (b) directly maps to panel (a) and shares a single continuous legend, the two panels MUST NOT be split. They must remain unified in a single high-resolution image (`WHEATER_HISTO_P352_Fig_18_5_seminiferous_tubule_unified.png`).

---

## Example 4: Wide Letter-Spaced Tracking Resolution (Developing Human)

### Context & Flawed Initial State
In *The Developing Human (10th Ed.)*, captions use tracked lettering:
```text
F I G U R E  1 2 – 1 8  Ectopic ureter in a young girl. The ureter enters the vestibule...
```
- Flaw 1: Regex `r"FIGURE 12-(\d+)"` failed to match, causing the figure to be omitted.
- Flaw 2: `text.replace(" ", "")` stripped spaces from the description, producing `F_I_G_U_R_E_1_2_1_8_Ectopic_ur.png` and colliding when multiple figures shared the first digit `1`.

### The Production Fix
```python
clean_num = re.sub(r"\s+", "", fb["figure_id"])
raw_num = re.search(r"12[\–\-](\d+)", clean_num).group(1) # Parses '18' correctly
raw_text = fb["text"].strip()
body = re.sub(r"^\s*F\s*I\s*G\s*U\s*R\s*E\s*1\s*2\s*[\–\-]\s*[0-9\s]+\s*", "", raw_text)
f_title = re.split(r"[\.\n]", body)[0].strip() # 'Ectopic ureter in a young girl'
slug = sanitize_slug(f_title, max_len=30)       # 'ectopic_ureter'
fn = f"DEV_HUMAN_P342_Fig_12_18_ectopic_ureter.png"
```
Result: All 49 numbered figures (`12-1` to `12-49`) are extracted with 100% distinct, human-readable medical filenames.

---

## Example 5: Flashcard Matching CLI (`match_for_card.py`)

### Query Execution
```bash
python3 match_for_card.py -q "podocyte filtration slit" -s "Histology" -k 1
```

### Response
```text
Found 1 Top Matching Visual:
======================================================================
#1 [Score: 13.82] Podocyte slit diaphragm filtration diagram
   Origin: University Lecture Slide
   Source: Lecture Slide: Lecture (3)- Histology - Urinary -2025-2026- Prof. Hanan Saleh.pdf (p. 19) | ID: Slide 19
   Subject: Histology | Lecture: General Histological Structure of the Kidney and Renal Corpuscle
   Dimensions: 700x543 px
   Caption: Podocyte slit diaphragm filtration diagram
   File Path: /Users/omarhossa/Documents/Codex/2026-09-20/h/Urogenital_Visual_Library/approved/Histology/General Histological Structure of the Kidney and Renal Corpuscle dae7f5f5/p019 - Podocyte slit diaphragm filtration diagram - FILE-d35101bcdae7f5f5-A-00137-jpg.png
   Anki Tag: <img src="p019 - Podocyte slit diaphragm filtration diagram - FILE-d35101bcdae7f5f5-A-00137-jpg.png">
```
