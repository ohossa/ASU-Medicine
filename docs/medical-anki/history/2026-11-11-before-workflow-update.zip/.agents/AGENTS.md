# ASU Portal Project Rules

## Documentation Synchronization Rule

> [!IMPORTANT]
> **Constraint**: Any time you modify the question bank structure, schema, subject lists, or the import pipeline scripts (`import-ready.ts`, `import-batch.ts`, or `intake-agent.ts`), you **MUST** update the corresponding documentation markdown files in the repository.
> 
> The specific files to keep synchronized are:
> 1. [schema.md](file:///Users/omarhossa/Documents/Medcine%20ASU/ASU-Medical-Portal/data-format-v2/schema.md) — The canonical database schema specification.
> 2. [HOW_TO_USE.md](file:///Users/omarhossa/Documents/Medcine%20ASU/ASU-Medical-Portal/data-format-v2/HOW_TO_USE.md) — Detailed guide on importer scripts, options, flags, and workflow.
> 3. [import-workflow.md](file:///Users/omarhossa/Documents/Medcine%20ASU/ASU-Medical-Portal/data-format-v2/import-workflow.md) — Importer sequence and features.
> 4. [ADDING_QUESTIONS.md](file:///Users/omarhossa/Documents/Medcine%20ASU/ASU-Medical-Portal/ADDING_QUESTIONS.md) — Quick start guide for adding new questions.

---

## Import & Auto-Routing Rules

- **Smart Auto-Sorting**: Always check for matching lecture names in the module's `lectureNames` list before performing fallback keyword matching. Smart routing matches the topic against `lectureNames` (exact match first, then substring match).
- **Subject Mappings**: Ensure ENT and Ophthalmology subjects in Anki / raw question files map correctly to the `"clinical"` subject ID in `MSS-2.json`.

---

## Medical Image & Visual Asset Rules

- **Workflow Authority**: Follow [IMAGE_EXTRACTION_WORKFLOW.md](file:///Users/omarhossa/Documents/Medcine%20ASU/ASU-Medical-Portal/IMAGE_EXTRACTION_WORKFLOW.md) and [.agents/skills/medical-image-extraction/SKILL.md](file:///Users/omarhossa/Documents/Medcine%20ASU/ASU-Medical-Portal/.agents/skills/medical-image-extraction/SKILL.md) for all textbook figure cropping, atlas plate extraction, and flashcard image cataloging.
- **Visual Invariants**: Native 300 DPI vector rendering (`fitz.Matrix(300/72, 300/72)`), 100% label retention, multi-figure splitting, sub-panel grouping integrity, zero body text bleed, zero synthetic Pillow cards, authentic caption stitching.
- **Verification Gates**: All extractions must pass `python3 tests/run_tests.py`, `python3 tests/run_tests.py --challenger`, and `pytest tests/test_e2e_visual_library.py -v`.
- **Integrity**: 100% 1:1 disk-to-index match (`UNIFIED_MASTER_IMAGE_INDEX.csv` and `.json`), zero unindexed files, and zero broken symlinks in `Urogenital_Unified_Curriculum_Library/`.

---

## Quality & Testing Rules

- **Auto-Verification**: After making any changes to the import scripts or the JSON files, you must run:
  - Vitest routing tests: `npx vitest run src/app/import-routing.test.ts`
  - Special Senses module tests: `npx vitest run src/app/special-senses.test.ts`
  - Bank JSON schema validator: `npx tsx data-format-v2/scripts/validate-banks.ts`

---

## Git & Release Rules

- **Git Push Constraint**: Do **NOT** push commits to GitHub (e.g., via `git push`) unless the user explicitly tells you to do so. You may commit changes locally, but pushing must be requested or approved by the user first.

---

## Skills & Memory Architecture

- **Operating Playbook**: Refer to [`docs/AGENT_SKILLS_AND_MEMORY_PLAYBOOK.md`](file:///Users/omarhossa/Documents/Medcine%20ASU/ASU-Medical-Portal/docs/AGENT_SKILLS_AND_MEMORY_PLAYBOOK.md) for skill triggers and the 4-tier memory hierarchy.
- **Project Scratchpad**: Consult and maintain [`MEMORY.md`](file:///Users/omarhossa/Documents/Medcine%20ASU/ASU-Medical-Portal/MEMORY.md) for persistent project gotchas, module code rules, and architectural invariants.


