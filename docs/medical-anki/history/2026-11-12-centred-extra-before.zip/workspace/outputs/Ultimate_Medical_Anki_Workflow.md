# Ultimate medical Anki workflow: start here

Version 2.0 · 10 November 2026

This is the reusable entrypoint for the linked card-creation and image-extraction process. Use it for any future medical module, adapting only the authorised sources, curriculum, baseline package and client environment. It carries forward the accepted GIT/urinary preferences without hardcoding their book offsets, IDs, counts or figures.

## Use in a new chat

```text
Use $medical-anki-production and $medical-image-extraction.
Read their complete workflows, then use Medical_Anki_Workflow_Start_Prompt.md
with the source paths and scope I provide. Preserve any published note identities.
Create/review text first, then enrich exact cards with reviewed images.
Deliver the tested APKG, full coverage/image breakdown and update instructions.
```

Fill in [the run prompt](Medical_Anki_Workflow_Start_Prompt.md). It specifies factual authority, book/lecture sources, current scope, parent deck, baseline, permitted changes, intended audience and output. Reuse existing authorisation; do not invent a live Anki write or publication request.

Read [the complete card workflow](Medical_Anki_Complete_Workflow.md) and [the image procedure](../IMAGE_EXTRACTION_WORKFLOW.md). The guides contain the detailed contracts and release gates; this page is an entrypoint, not a substitute.

## What the process delivers

1. Preserve source files and hashes; establish verified chapter/lecture names and printed-page mappings. Bookmarks are navigation aids.
2. Analyse all authorised exams/formative papers and OCR/inspect unclear content. Preserve duplicate occurrences, uncertain dates and answer-only/source holds.
3. Reconcile every substantive source point/table/legend/footnote with a note, equivalent, specific exclusion or hold; audit subject-specific categories such as complete parasitology coverage.
4. Write and review concise Basic/Cloze recall in bounded batches. Preserve useful enumerations, qualifiers and tested ranges; reject vague/tautological/leaking/trivial/duplicate prompts. Underline only verified essential exam keywords.
5. Freeze passing medical fields and immutable IDs/models. Extract native images and composite views; curate exact figures and pair them to the recall target with a separate hash-bound review. Add images in Extra only, unless another change is explicitly authorised and tested.
6. Verify the actual APKG through fresh/repeat/established-history updates and future faculty-list/media simulation when promised. Verify fields, media hashes, IDs, scheduling/revlog, light/dark mobile/desktop-width native HTML and actual representative views.
7. Deliver APKG, detailed subject/lecture statistics, source/coverage/media records, release notes and student update instructions. Preserve earlier releases and stop at the agreed boundary.

Image work explicitly handles upright orientation, proportions, vector labels, genuine captions/keys, clean crop edges, native-raster exceptions, online provenance/reuse, review deltas and interrupted batches. No fixed image percentage or fake resolution threshold substitutes for actual educational fit.

## Saved skills and portability

Local Codex user scope:

- `~/.codex/skills/medical-anki-production/`
- `~/.codex/skills/medical-image-extraction/`

The same folders are linked from `~/.agents/skills/`; one canonical local copy avoids divergent installed versions. This does not sync to another computer or account. Restart/open a new chat if its skill list predates installation.

[Medical_Anki_Workflow_Kit.zip](Medical_Anki_Workflow_Kit.zip) includes both self-contained skill folders, the guides, starting prompt and validation evidence. On another computer, place the two skill folders in its supported user skill directory, preserving their sibling names. Another AI without skills can read the included guides and run prompt. No textbooks, lecture images or student data are included in the kit.

The optional `medical-image-extraction/scripts/verify_visual_bundle.py` is a read-only evidence gate for new jobs without an equivalent validator; it requires Python 3.11+ and Pillow. It checks source/image/draft hashes, dimensions, exact canonical note-ID coverage and asset/pair review coverage. It neither performs medical/visual review nor packages APKGs. Read its bundle contract before use; do not migrate an existing sound project merely to use it.

## What was tested and what this does not promise

The urinary implementation passed 38 project tests, native imports/updates and 10,272 rendered faces. The new portable evidence validator passed 16 regression cases, including tampering, stale/missing review, duplicate IDs, missing appended notes and clear small-raster acceptance. A separate AI forward pass viewed two real figures and exercised update/recovery scenarios; it found a canonical-ID completeness hole that was fixed and independently retested. Its historical figure scenarios were outcome-informed, not a blind clinical evaluation. See [the validation record](Medical_Anki_Workflow_Validation.md).

These are observed checks, not guarantees of future medical correctness or universal compatibility. Each future deck needs fresh evidence. Qualified clinical review, actual mobile-client tests and audience-specific image permissions must be reported truthfully; a workflow cannot supply approvals that did not occur.

The prior guides/handoff are archived under `workflow_history/2026-11-10/`. Current workspace guides and installed references are mirrored copies; an authorised future edit must synchronise both and rerun their validators/tests. Do not reinstate the earlier “all catalogue images perfect/never recrop” claims.
