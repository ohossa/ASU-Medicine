"""Build the text-only review package from the canonical note registry."""
from pathlib import Path
from collections import Counter
import html
import json
import re
import genanki
from core import PALETTE, note_guid, stable_id, validate_card
from intake import ROOT, write_csv, write_json


def stylesheet():
    light, dark = PALETTE['light'], PALETTE['dark']
    return f'''
.card {{ font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Arial, sans-serif;
font-size: 20px; line-height: 1.55; text-align: left; color: {light['text']};
background: {light['background']}; margin: 0; padding: 22px; overflow-wrap: break-word; }}
.content {{ max-width: 760px; margin: auto; }}
.answer {{ margin-top: 22px; padding-top: 16px; border-top: 1px solid #888; }}
.extra {{ margin-top: 20px; }}
.extra-box {{ padding: 16px; border: 2px dashed {light['extra_border']}; border-radius: 10px; }}
.extra-title {{ margin: 0 0 14px; font-size: 1em; font-weight: 600; text-align: center; color: {light['extra_title']}; }}
.extra-content > br:first-child {{ display: none; }}
.source {{ margin-top: 24px; font-size: 14px; color: {light['muted']}; }}
.faculty {{ margin-top: 16px; font-size: 15px; font-weight: 600; }}
.artery {{ color: {light['artery']}; }} .vein {{ color: {light['vein']}; }}
.cloze {{ font-weight: 600; }} img {{ max-width: 100%; height: auto; }}
.nightMode, .night_mode, .card.nightMode {{ background: {dark['background']}; color: {dark['text']}; }}
.nightMode .source, .night_mode .source {{ color: {dark['muted']}; }}
.nightMode .artery, .night_mode .artery {{ color: {dark['artery']}; }}
.nightMode .vein, .night_mode .vein {{ color: {dark['vein']}; }}
.nightMode .extra-box, .night_mode .extra-box {{ border-color: {dark['extra_border']}; }}
.nightMode .extra-title, .night_mode .extra-title {{ color: {dark['extra_title']}; }}
.cloze-answer .cloze {{ color: {light['cloze_answer']}; }}
.nightMode .cloze-answer .cloze, .night_mode .cloze-answer .cloze {{ color: {dark['cloze_answer']}; }}
.cloze-answer .cloze * {{ color: inherit; }}
@media (max-width: 480px) {{ .card {{ padding: 16px; font-size: 19px; }} .extra-box {{ padding: 12px 10px; }} }}
'''


def make_models():
    tail = '{{#Extra}}<div class="extra">{{Extra}}</div>{{/Extra}}' + '{{#FacultyDrugList}}<div class="faculty">Faculty drug list</div>{{/FacultyDrugList}}' + '<div class="source">{{Source}}</div></div>'
    basic_tail = tail.replace('<div class="extra">{{Extra}}</div>', '<div class="extra extra-box"><h3 class="extra-title">Extra Section</h3><div class="extra-content">{{Extra}}</div></div>')
    basic = genanki.Model(stable_id('asu-ug:basic:v1'), 'ASU Urogenital Basic v1',
        fields=[{'name': x} for x in ['Front', 'Back', 'Extra', 'Source', 'FacultyDrugList']],
        templates=[{'name': 'Recall', 'qfmt': '<div class="content">{{Front}}</div>',
            'afmt': '<div class="content">{{Front}}<div class="answer">{{Back}}</div>' + basic_tail}], css=stylesheet())
    cloze = genanki.Model(stable_id('asu-ug:cloze:v1'), 'ASU Urogenital Cloze v1',
        fields=[{'name': x} for x in ['Text', 'Extra', 'Source', 'FacultyDrugList']],
        templates=[{'name': 'Recall', 'qfmt': '<div class="content">{{cloze:Text}}</div>',
            'afmt': '<div class="content cloze-answer">{{cloze:Text}}' + tail}], css=stylesheet(), model_type=genanki.Model.CLOZE)
    return {'Basic': basic, 'Cloze': cloze}


def source_text(card):
    grouped = {}
    for anchor in card['anchors']:
        grouped.setdefault(anchor['part'], []).append(int(anchor['printed_page']))
    labels = []
    for part, nums in grouped.items():
        nums = sorted(set(nums))
        page = str(nums[0]) if len(nums) == 1 else f'{nums[0]}–{nums[-1]}' if nums == list(range(nums[0], nums[-1]+1)) else ', '.join(map(str, nums))
        labels.append(f'Part {part}, {"p." if len(nums)==1 else "pp."} {page}')
    return 'Urogenital Module, 4th ed., ' + '; '.join(labels)


def lecture_for(card, curriculum):
    matches = [l for l in curriculum if l['part'] == card['part'] and l['title'] == card['lecture'] and l['subject'] == card['subject']]
    if len(matches) != 1:
        raise ValueError(f'Unresolved lecture: {card["id"]}: {card["lecture"]}: {len(matches)}')
    return matches[0]


def lecture_tag(lecture):
    names = ['UG', 'Part 1: Urinary System' if lecture['part'] == 1 else 'Part 2: Genital System']
    if lecture['grouping']: names.append(lecture['grouping'])
    names.extend([lecture['subject'], lecture['title']])
    return '::'.join(re.sub(r'[^\w]+', '_', n).strip('_') for n in names)


def field_html(value):
    return re.sub(r'<(?=[\s\d=])', '&lt;', value)


def build_package(cards, out, timestamp=None, media_files=(), description=None):
    curriculum = json.loads((ROOT / 'manifests/curriculum.json').read_text())
    models = make_models()
    media_paths = {str(Path(p).resolve()) for p in media_files}
    media_names = [Path(p).name for p in media_paths]
    if len(set(media_names)) != len(media_names): raise ValueError('Duplicate media filenames')
    if any(not Path(p).is_file() for p in media_paths): raise ValueError('Missing media file')
    references = {name for c in cards for value in [c.get('front', ''), c.get('back', ''), c.get('text', ''), c.get('extra', '')] for name in re.findall(r'<img\b[^>]*\bsrc=[\"\x27]([^\"\x27]+)[\"\x27]', value, re.I)}
    if references != set(media_names): raise ValueError(f'Unresolved or unused media: references={references}, files={set(media_names)}')
    description = description or 'Urogenital Module 4th edition. Review checkpoint: text only; image enrichment follows text approval.'
    decks = {l['deck']: genanki.Deck(stable_id('asu-ug:deck:' + l['id']), l['deck'], description=description) for l in curriculum}
    for c in cards:
        errors = validate_card(c)
        if errors: raise ValueError(f'{c["id"]}: {errors}')
        lecture = lecture_for(c, curriculum)
        fields = [c['front'], c['back']] if c['type'] == 'Basic' else [c['text']]
        fields += [c.get('extra', ''), source_text(c), c.get('faculty_drug_list', '')]
        fields = [field_html(value) for value in fields]
        shared = [next(l for l in curriculum if l['id'] == lid) for lid in c.get('shared_lecture_ids', [])]
        tags = sorted(set([lecture_tag(lecture), *[lecture_tag(l) for l in shared], *c.get('tags', [])]))
        decks[lecture['deck']].add_note(genanki.Note(model=models[c['type']], guid=note_guid(c['id']), fields=fields, tags=tags))
    out = Path(out)
    out.parent.mkdir(parents=True, exist_ok=True)
    genanki.Package(list(decks.values()), media_files=sorted(media_paths)).write_to_file(str(out), timestamp=timestamp)


def main():
    cards = json.loads((ROOT / 'cards/pilot.json').read_text())
    assert len(cards) == 40
    assert len({c['id'] for c in cards}) == 40
    curriculum = json.loads((ROOT / 'manifests/curriculum.json').read_text())
    pages = json.loads((ROOT / 'manifests/book_pages.json').read_text())
    page_map = {(p['part'], p['pdf_page']): p for p in pages}
    reference_checks = {(x['part'], x['pdf_page']): x for x in json.loads((ROOT / 'reviews/reference_checks.json').read_text())}
    registry, evidence = [], []
    for c in cards:
        lecture = lecture_for(c, curriculum)
        for a in c['anchors']:
            page = page_map[a['part'], a['pdf_page']]
            if a['quote'].casefold() not in page['text'].casefold(): raise ValueError(f'Missing evidence: {c["id"]}: {a["quote"]}')
            check = reference_checks.get((a['part'], a['pdf_page']))
            if check and check['printed_page'] != a['printed_page']: raise ValueError('Reference review mismatch')
            evidence.append({'note_id': c['id'], **a, 'source_text': page['text'], 'support_status': 'source_passage_checked', 'reference_status': check['method'] if check else 'footer_ocr_match' if page['printed_page'] else 'printed_sequence_reference; visual footer review required'})
        registry.append({'note_id': c['id'], 'guid': note_guid(c['id']), 'type': c['type'], 'deck': lecture['deck'],
            'lecture_id': lecture['id'], 'source': source_text(c), 'subject': c['subject'], 'stage': 'sample_for_user_review'})
    build_package(cards, ROOT / 'releases/Urogenital - 40 Card Review Sample v0.1.apkg')
    write_json('manifests/note_registry.json', registry)
    write_csv('manifests/lecture_searches.csv', [{'lecture_id': l['id'], 'lecture': l['title'], 'subject': l['subject'], 'search': 'tag:' + lecture_tag(l)} for l in curriculum])
    write_json('reviews/pilot_source_evidence.json', evidence)
    write_csv('reviews/pilot_cards.csv', [{'id': c['id'], 'subject': c['subject'], 'type': c['type'],
        'question': c.get('front', c.get('text')), 'answer': c.get('back', ''), 'reference': source_text(c)} for c in cards])
    fragments = json.loads((ROOT / 'exams/fragments.json').read_text())
    links = []
    for c in cards:
        for f in fragments:
            matches = [q for q in c.get('exam_queries', []) if q.casefold() in f['text'].casefold()]
            if matches: links.append({'note_id': c['id'], 'fragment_id': f['id'], 'matched_queries': matches, 'status': 'candidate_topic_link; no frequency claim'})
    write_json('exams/pilot_topic_links.json', links)
    coverage = json.loads((ROOT / 'manifests/book_coverage.json').read_text())
    for block in coverage:
        linked = [c['id'] for c in cards for a in c['anchors'] if a['part'] == block['part'] and a['pdf_page'] == block['pdf_page'] and a['quote'].casefold() in block['source_text'].casefold()]
        if linked:
            block['note_ids'] = sorted(set(linked))
            block['status'] = 'partially_covered_by_pilot; remaining claims pending review'
    write_json('manifests/book_coverage.json', coverage)
    write_csv('manifests/book_coverage.csv', [{**b, 'bbox': json.dumps(b['bbox']), 'note_ids': ';'.join(b['note_ids'])} for b in coverage])
    sections = []
    for c in cards:
        if c['type'] == 'Basic':
            question, answer = c['front'], c['back']
        else:
            question = re.sub(r'\{\{c1::(.*?)\}\}', '<span class="cloze">[…]</span>', c['text'])
            answer = re.sub(r'\{\{c1::(.*?)\}\}', r'<span class="cloze">\1</span>', c['text'])
        sections.append(f'<article><p class="meta">{c["id"]} · {html.escape(c["subject"])} · {c["type"]}</p><div class="question">{question}</div><details open><summary>Answer</summary><div class="answer">{answer}</div><div class="source">{source_text(c)}</div></details></article>')
    content = '<!doctype html><html><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Urogenital 40-card review</title><style>' + stylesheet() + 'article{max-width:760px;margin:0 auto 32px;padding-bottom:24px;border-bottom:1px solid #888}.meta{font-size:14px}.mode{margin-bottom:24px}summary{margin-top:16px;cursor:pointer} .answer{border:0}</style><body class="card"><div class="mode"><button onclick="document.body.classList.toggle(\'nightMode\')">Light / dark</button></div>' + ''.join(sections) + '</body></html>'
    (ROOT / 'reviews/pilot_preview.html').write_text(content)
    print(json.dumps({'notes': len(cards), 'types': dict(Counter(c['type'] for c in cards)), 'subjects': dict(Counter(c['subject'] for c in cards)), 'source_anchors': len(evidence)}, indent=2))


if __name__ == '__main__': main()
