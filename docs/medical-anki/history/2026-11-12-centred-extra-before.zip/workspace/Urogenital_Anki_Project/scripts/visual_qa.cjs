// Exercise Anki-rendered HTML in Chromium; native mobile clients need device testing.
const fs = require('node:fs');
const crypto = require('node:crypto');
const path = require('node:path');
const { pathToFileURL } = require('node:url');
const { chromium } = require('/Users/omarhossa/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const root = path.resolve(__dirname, '..');
const styled = process.argv.includes('--styled');
const urinary = styled || process.argv.includes('--part1') || process.argv.includes('--urinary');
const full = process.argv.includes('--full');
const illustrated = styled || process.argv.includes('--illustrated');
if (full && urinary) throw new Error('Choose one scope');
if (illustrated && !urinary) throw new Error('--illustrated requires --part1');

(async () => {
  const faceBytes = fs.readFileSync(path.join(root, styled ? 'reviews/native_urinary_styled_card_faces.json' : illustrated ? 'reviews/native_urinary_illustrated_card_faces.json' : urinary ? 'reviews/native_urinary_card_faces.json' : full ? 'reviews/native_full_card_faces.json' : 'reviews/native_card_faces.json'));
  const faces = JSON.parse(faceBytes);
  const notes = styled ? new Map(JSON.parse(fs.readFileSync(path.join(root, 'cards/urinary_system_enriched.json'), 'utf8')).map(n => [n.id, n])) : null;
  if (!faces.length || new Set(faces.map(f => `${f.id}:${f.face}`)).size !== faces.length) throw new Error('Empty or duplicated native faces');
  const out = path.join(root, styled ? 'reviews/urinary_styled_screenshots' : illustrated ? 'reviews/urinary_illustrated_screenshots' : urinary ? 'reviews/urinary_screenshots' : full ? 'reviews/full_screenshots' : 'reviews/screenshots');
  const selected = new Set();
  if (full || urinary) {
    const answers = faces.filter(f => f.face === 'answer');
    for (const subject of new Set(answers.map(f => f.subject))) {
      answers.filter(f => f.subject === subject).sort((a, b) => b.html.length - a.html.length).slice(0, 2).forEach(f => selected.add(f.id));
      if (illustrated) answers.filter(f => f.subject === subject && f.html.includes('<img')).slice(0, 2).forEach(f => selected.add(f.id));
    }
    answers.filter(f => f.html.includes('<span class="cloze"')).slice(0, 4).forEach(f => selected.add(f.id));
  }
  if (styled) {
    selected.add('UG-P1-L001-N010'); // The user's posterior kidney example: text plus image in Extra.
    const empty = [...notes.values()].find(n => n.type === 'Basic' && !n.extra);
    if (empty) selected.add(empty.id);
  }
  fs.mkdirSync(out, { recursive: true });
  const browser = await chromium.launch({ headless: true, executablePath: '/Users/omarhossa/Library/Caches/ms-playwright/chromium_headless_shell-1223/chrome-headless-shell-mac-arm64/chrome-headless-shell' });
  const page = await browser.newPage();
  if (illustrated) await page.goto(pathToFileURL(path.join(root, 'reviews/pilot_preview.html')).href);
  const base = illustrated ? `<base href="${pathToFileURL(path.join(root, 'media/urinary_selected') + path.sep).href}">` : '';
  const failures = [];
  const rows = [];
  let screenshots = 0;
  const widths = styled ? [320, 390, 1100] : [390, 1100];
  for (const width of widths) {
    for (const mode of ['light', 'dark']) {
      await page.setViewportSize({ width, height: 900 });
      for (const face of faces) {
        const classname = mode === 'dark' ? 'card nightMode' : 'card';
        await page.setContent(`<!doctype html><meta charset="utf-8">${base}<meta name="viewport" content="width=device-width,initial-scale=1"><body class="${classname}">${face.html}</body>`);
        const geometry = await page.evaluate(() => ({
          scroll: document.documentElement.scrollWidth,
          viewport: window.innerWidth,
          visibleText: document.body.innerText,
          bodyHeight: document.body.scrollHeight,
          images: [...document.images].map(i => ({ loaded: i.complete && i.naturalWidth > 0, alt: i.getAttribute('alt'),
            ratio: (i.getBoundingClientRect().width / i.getBoundingClientRect().height) / (i.naturalWidth / i.naturalHeight) })),
        }));
        if (geometry.scroll > geometry.viewport + 1) failures.push({ id: face.id, mode, width, reason: 'horizontal overflow' });
        if (geometry.visibleText.includes('{{') || geometry.visibleText.includes('undefined')) failures.push({ id: face.id, mode, width, reason: 'unrendered template' });
        if (illustrated && geometry.images.some(i => !i.loaded || !Number.isFinite(i.ratio) || Math.abs(i.ratio - 1) > .01)) failures.push({ id: face.id, mode, width, reason: 'missing or distorted image' });
        if (illustrated && geometry.images.some(i => !i.alt?.trim())) failures.push({ id: face.id, mode, width, reason: 'missing image description' });
        if (styled) {
          const note = notes.get(face.id);
          const checks = await page.evaluate(({ type, answer, hasExtra, width }) => {
            const failures = [];
            const contrast = (a, b) => {
              const luminance = colour => {
                const c = colour.match(/[\d.]+/g).slice(0, 3).map(Number).map(v => v / 255).map(v => v <= .04045 ? v / 12.92 : ((v + .055) / 1.055) ** 2.4);
                return c[0] * .2126 + c[1] * .7152 + c[2] * .0722;
              };
              const [x, y] = [luminance(a), luminance(b)].sort((x, y) => x - y);
              return (y + .05) / (x + .05);
            };
            const body = getComputedStyle(document.body);
            if (body.fontSize !== `${width <= 480 ? 19 : 20}px` || body.textAlign !== 'left' || Math.abs(parseFloat(body.lineHeight) / parseFloat(body.fontSize) - 1.55) > .001) failures.push('approved typography changed');
            const boxes = [...document.querySelectorAll('.extra-box')];
            if (boxes.length !== (type === 'Basic' && answer && hasExtra ? 1 : 0)) failures.push('extra box conditional/scope');
            for (const box of boxes) {
              const title = box.querySelector('.extra-title');
              const style = getComputedStyle(box);
              if (title?.textContent !== 'Extra Section' || !box.querySelector('.extra-content') || style.borderTopStyle !== 'dashed') failures.push('extra panel structure');
              if (title && contrast(getComputedStyle(title).color, body.backgroundColor) < 4.5) failures.push('extra title contrast');
              if (contrast(style.borderTopColor, body.backgroundColor) < 3) failures.push('extra border contrast');
              if (box.querySelector('.answer, .source')) failures.push('answer/source inside extra panel');
            }
            const clozes = [...document.querySelectorAll('.cloze-answer .cloze')];
            if (type === 'Cloze' && answer && !clozes.length) failures.push('missing highlighted cloze answers');
            if (!answer && document.querySelector('.cloze-answer')) failures.push('answer scope on question');
            for (const cloze of clozes) {
              const colour = getComputedStyle(cloze).color;
              if (colour === body.color || contrast(colour, body.backgroundColor) < 4.5) failures.push('cloze answer contrast/distinction');
              if ([...cloze.querySelectorAll('*')].some(child => getComputedStyle(child).color !== colour)) failures.push('nested cloze colour overridden');
            }
            return failures;
          }, { type: note.type, answer: face.face === 'answer', hasExtra: Boolean(note.extra), width });
          for (const reason of checks) failures.push({ id: face.id, mode, width, reason });
        }
        rows.push({ id: face.id, face: face.face, width, mode, height: geometry.bodyHeight });
        if (face.face === 'answer' && (!(full || urinary) || selected.has(face.id))) {
          await page.screenshot({ path: path.join(out, `${face.id}-${width}-${mode}.png`), fullPage: true });
          screenshots++;
        }
      }
    }
  }
  await browser.close();
  if (rows.length !== faces.length * widths.length * 2) throw new Error('Incomplete mode/viewport checks');
  const report = { status: failures.length ? 'FAIL' : 'PASS', facesChecked: rows.length, screenshots, failures, rows,
    environment: `Chromium rendering of real Anki backend HTML at ${widths.join('/')}px; light and dark modes`, nativeMobileClientsTested: false };
  report.nativeFacesSHA256 = crypto.createHash('sha256').update(faceBytes).digest('hex');
  if (styled) report.packageSHA256 = crypto.createHash('sha256').update(fs.readFileSync(path.join(root, 'releases/Urogenital - Part 1 Urinary System - Style Update.apkg'))).digest('hex');
  fs.writeFileSync(path.join(root, styled ? 'reports/urinary_styled_visual_qa.json' : illustrated ? 'reports/urinary_illustrated_visual_qa.json' : urinary ? 'reports/urinary_visual_qa.json' : full ? 'reports/production_visual_qa.json' : 'reports/visual_qa.json'), JSON.stringify(report, null, 2));
  console.log(JSON.stringify({ status: report.status, facesChecked: rows.length, failures }, null, 2));
  if (failures.length) process.exitCode = 1;
})().catch(error => { console.error(error); process.exitCode = 1; });
