import json
import sys
import tempfile
import unittest
from copy import deepcopy
from pathlib import Path

from anki.collection import Collection

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))
from build import build_package, make_models
from core import PALETTE, contrast, note_guid
from verify_production import export, ingest


class StyleUpdateTests(unittest.TestCase):
    def test_extra_box_is_answer_only_and_conditional(self):
        source = json.loads((ROOT / 'cards/pilot.json').read_text())
        cards = deepcopy([c for kind in ['Basic', 'Cloze'] for c in [n for n in source if n['type'] == kind][:2]])
        for index, card in enumerate(cards):
            card['extra'] = 'Synthetic supplementary test content.' if index % 2 == 0 else ''
        with tempfile.TemporaryDirectory() as tmp:
            package = Path(tmp) / 'fixture.apkg'
            build_package(cards, package)
            col = Collection(str(Path(tmp) / 'test.anki2'))
            try:
                ingest(col, package)
                for index, record in enumerate(cards):
                    note = col.get_note(col.db.scalar('select id from notes where guid=?', note_guid(record['id'])))
                    card = note.cards()[0]
                    self.assertNotIn('Extra Section', card.question())
                    if record['extra']:
                        self.assertIn('class="extra extra-box"', card.answer())
                        self.assertIn('Extra Section', card.answer())
                        self.assertIn('Synthetic supplementary test content.', card.answer())
                    else:
                        self.assertNotIn('Extra Section', card.answer())
                        self.assertNotIn('class="extra extra-box"', card.answer())
            finally:
                col.close()

    def test_new_text_colours_have_accessible_contrast(self):
        for mode in PALETTE.values():
            for role in ['cloze_answer', 'extra_title']:
                self.assertGreaterEqual(contrast(mode[role], mode['background']), 4.5)
                self.assertNotEqual(mode[role], mode['text'])
            self.assertGreaterEqual(contrast(mode['extra_border'], mode['background']), 3)

    def test_style_import_updates_templates_but_preserves_local_fields(self):
        cards = deepcopy(json.loads((ROOT / 'cards/pilot.json').read_text())[:2])
        with tempfile.TemporaryDirectory() as tmp:
            package = Path(tmp) / 'fixture.apkg'
            build_package(cards, package)
            col = Collection(str(Path(tmp) / 'recipient.anki2'))
            try:
                ingest(col, package)
                # Exercise the native export format used by the published release.
                native = Path(tmp) / 'native.apkg'
                export(col, native)
                model = make_models()['Basic']
                changed = col.models.get(model.model_id)
                changed['css'] = '.card { color: black; }'
                col.models.update_dict(changed)
                note = col.get_note(col.db.scalar('select id from notes where guid=?', note_guid(cards[0]['id'])))
                note['Back'] += ' Recipient-only test edit.'
                col.update_note(note)
                before = col.db.all('select * from notes order by id')
                before_cards = col.db.all('select * from cards order by id')
                ingest(col, native, style_only=True)
                self.assertEqual(col.models.get(model.model_id)['css'], model.css)
                self.assertEqual(col.db.all('select * from notes order by id'), before)
                self.assertEqual(col.db.all('select * from cards order by id'), before_cards)
            finally:
                col.close()


if __name__ == '__main__':
    unittest.main()
