# Medical Anki and visual-library handoff

Updated 10 November 2026. Workspace: `/Users/omarhossa/Documents/Codex/2026-09-20/h`.

## Current release and boundary

Urinary Part 1 is complete at the tested illustrated release:

- `Urogenital_Anki_Project/releases/Urogenital - Part 1 Urinary System - Illustrated.apkg`
- 1,284 cards, 34 home lecture decks; 1,256 Basic + 28 Cloze.
- 494 illustrated cards, 515 placements, 195 unique packaged images.
- Native Anki fresh/repeat/update and media checks PASS; all 10,272 light/dark mobile/desktop-width faces PASS; 38 project tests PASS.
- Details, source holds, remaining optional image opportunities and limits: `Urogenital_Anki_Project/reports/PART_1_FINAL_ANALYSIS.md`.

**Part 2 genital production is paused. Do not begin until the user explicitly requests it.** The 11 historical genital pilot notes and prepared source packets are retained, outside the 1,284-card urinary release. Read `Urogenital_Anki_Project/production/PART_2_PAUSED_HANDOFF.md` on explicit resumption. Preserve the current 77-lecture curriculum and immutable published pilot IDs.

## Read these current workflows

1. `outputs/Ultimate_Medical_Anki_Workflow.md`: entrypoint and reusable-skill invocation.
2. `outputs/Medical_Anki_Complete_Workflow.md`: full text, source, exam, identity, update and release procedure.
3. `IMAGE_EXTRACTION_WORKFLOW.md`: current extraction, crop, fidelity, visual review and pairing procedure.
4. `outputs/Medical_Anki_Workflow_Start_Prompt.md`: inputs for a future authorised run.

Installed local user-scope skills:

- `/Users/omarhossa/.codex/skills/medical-anki-production/SKILL.md`
- `/Users/omarhossa/.codex/skills/medical-image-extraction/SKILL.md`

Both are linked from `/Users/omarhossa/.agents/skills/`. This is local installation, not account/cloud synchronisation.

## Visual sources and review truth

The historical unified catalogue contains 5,904 candidates (reference-book and university visual libraries). It is a retrieval pool, **not a blanket quality approval**. The former handoff's statements “100% mathematically verified”, “all ready for immediate use”, “every image native 300 DPI” and blanket ban on recropping are superseded. The previous handoff remains in `outputs/workflow_history/2026-11-10/CODEX_FLASHCARD_GENERATION_HANDOFF.previous.md` for directory/history reference; its quality claims are not current evidence.

Actual Part 1 review found crop, caption/key, label, proportions and relevance problems in candidates. Preserve the original libraries/catalogues, inspect exact candidates against their source and card, and create necessary corrected display derivatives under the project. A clear native raster can be better than a distorted PDF placement; do not fake higher resolution. Review all visible medical text, including peripheral mechanism labels. Exact source-page/figure/crop/hash and separate pairing evidence are required.

Important directories (inspect their actual manifests, not the old handoff's edition/count claims):

- `Urogenital_Textbook_Visual_Library/`: reference-textbook candidate figures by source.
- `Urogenital_Visual_Library/approved/`: historically classified university candidates; folder name is not current approval.
- `Urogenital_Visual_Library/embedded/`: original extracted lecture raster assets.
- `Urogenital_Unified_Curriculum_Library/`: curriculum browsing links; audit targets before use, never copy symlinks as Anki media.
- `UNIFIED_MASTER_IMAGE_INDEX.csv` and `.json`: retrieval catalogue. Inspect actual schema, duplicates and file existence before querying.
- `Urogenital_Anki_Project/production/images/`: canonical B01–B06 selections and hash-bound second reviews.
- `Urogenital_Anki_Project/media/book_recrops/`: corrected native viewport crops and authentic caption/key derivatives with source manifests.
- `Urogenital_Anki_Project/reports/urinary_media_manifest.json`: actual final 515 pairings/195 packaged assets and 790 no-image decisions.

A matcher is a retrieval aid only. Fix duplicate loading and verify its current CLI before use; never attach its first hit automatically. The old handoff's example commands/APIs are historical and may differ from installed tools. Do not alter the user's live Anki, reorganise source files or publish without current authorisation.

## Medical and update contract

The supplied module books remain tested-text authority. Past exams/formatives guide style and emphasis after book verification; unresolved/answer-only fragments remain explicit holds. Preserve concise standalone recall, complete useful enumerations, UK English, restrained emphasis, subtle verified exam-keyword underlining and approved system fonts. Use Basic/Cloze by task without quotas. Images appear after answering in Extra and must support the exact recall target; no image spam.

Freeze source-grounded text during image work. Preserve note GUIDs, model/field/template identities, Cloze numbers and recipient scheduling. Every future release requires its own source/coverage, visual/pair, native fresh/repeat/update, media and rendered-face checks. Do not treat this release's tests as approval of future images or parts. Report actual device/client tests separately from browser emulation and AI source reviews separately from independent clinician review.
