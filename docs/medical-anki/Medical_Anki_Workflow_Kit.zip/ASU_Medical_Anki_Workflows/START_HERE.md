# Medical Anki workflow kit v2.2

Read docs/medical-anki/START_HERE.md, then fill in MEDICAL_ANKI_START_PROMPT.md. The two complete skills are under .agents/skills/. Runtime aliases described in the full repository guide are optional and are not required by this kit. Use the five approved assets in medical-anki-production for BOTH Basic and Cloze centred Extra. No source books, images, APKGs or prior-chat access are included.

Use direct study wording and keep image credits out of Anki deck descriptions.
